

package casa;

/**
 *
 * @author pedro
 */
public class Pessoa {

    String nome;
    int idade;
    
    public int fazAniersario(){
        return idade++; 
 }
    
    
    
}
